# React-WeatherApp
A responsive weather app built with React that fetches real-time data from the OpenWeatherMap API. Users can search for cities to view weather details like temperature, humidity, and wind speed. The app features error handling, a clean UI, and supports multiple cities.
